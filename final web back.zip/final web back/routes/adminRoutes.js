// adminRoutes.js
// Import necessary modules and controllers
const express = require('express');
const router = express.Router();
const multer = require('multer'); // Middleware for handling multipart/form-data
const AdminController = require('../controllers/AdminController'); // Import the AdminController

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/'); // Specify the destination directory for uploaded files
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname); // Define the filename after upload
    }
});
const upload = multer({ storage: storage });

// Define routes for the admin interface
router.get('/', AdminController.getAdminDashboard); // Route to render the admin dashboard
router.get('/add', AdminController.getAddPortfolioItem); // Route to render the add portfolio item form
router.post('/add', upload.array('images', 3), AdminController.postAddPortfolioItem); // Route to handle adding a new portfolio item
router.post('/delete/:id', AdminController.deletePortfolioItem); // Route to handle deleting a portfolio item
router.get('/edit/:id', AdminController.getEditPortfolioItem); // Route to render the edit portfolio item form
router.post('/edit/:id', upload.array('images', 3), AdminController.postEditPortfolioItem); // Route to handle updating a portfolio item

module.exports = router; // Export the router for use in the application
