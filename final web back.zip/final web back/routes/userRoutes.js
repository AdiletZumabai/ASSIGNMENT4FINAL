// userRoutes.js
// Import necessary modules and controllers
const express = require('express');
const router = express.Router();
const UserController = require('../controllers/UserController'); // Import the UserController

// Define routes for user-related functionality
router.get('/', UserController.getIndex); // Route to render the index page
router.get('/register', UserController.getRegister); // Route to render the registration form
router.post('/register', UserController.postRegister); // Route to handle user registration
router.get('/login', UserController.getLogin); // Route to render the login form
router.post('/login', UserController.postLogin); // Route to handle user login
router.get('/reset-password', UserController.getResetPassword); // Route to render the reset password form
router.post('/reset-password', UserController.postResetPassword); // Route to handle password reset
router.get('/dashboard', UserController.getDashboard); // Route to render the user dashboard
router.get('/logout', UserController.logout); // Route to handle user logout

module.exports = router; // Export the router for use in the application

