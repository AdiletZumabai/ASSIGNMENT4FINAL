// models/User.js
// Import mongoose module for MongoDB interactions
const mongoose = require('mongoose');
// Define Schema object from mongoose
const Schema = mongoose.Schema;

// Define user schema with specified fields and types
const userSchema = new Schema({
    username: String, // Username of the user
    password: String, // Password of the user
    firstName: String, // First name of the user
    lastName: String, // Last name of the user
    age: Number, // Age of the user
    country: String, // Country of the user
    gender: String, // Gender of the user
    loginAttempts: { type: Number, default: 0 } // Number of login attempts, defaults to 0
});

// Create User model using the userSchema
const User = mongoose.model('User', userSchema);

// Export the User model for use in other modules
module.exports = User;
