document.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await fetch('/api/weather');
        const weatherDataArray = await response.json();

        const cities = weatherDataArray.map(data => data.city);
        const temperaturesCelsius = weatherDataArray.map(data => (data.temperature - 273.15).toFixed(2)); // Конвертация в градусы Цельсия

        const ctx = document.getElementById('weatherChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: cities,
                datasets: [{
                    label: 'Temperature (Celsius)',
                    data: temperaturesCelsius,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    } catch (error) {
        console.error('Error fetching weather data:', error);
    }
});