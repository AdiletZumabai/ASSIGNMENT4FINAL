// UserController.js
// Import necessary modules and models
const User = require('../models/User'); // Import the User model
const bcrypt = require('bcrypt'); // Module for password hashing
const nodemailer = require('nodemailer'); // Module for sending emails

// Define UserController object to handle user-related operations
const UserController = {
    // Method to render the index page
    getIndex: (req, res) => {
        res.render('index'); // Render the index view
    },

    // Method to render the registration form
    getRegister: (req, res) => {
        res.render('register'); // Render the register view
    },

    // Method to handle user registration
    postRegister: async (req, res) => {
        try {
            // Extract user information from request body
            const { username, password, firstName, lastName, age, country, gender } = req.body;

            // Check if the username already exists in the database
            const existingUser = await User.findOne({ username });

            if (existingUser) {
                const errorMessage = 'User with this username already exists';
                return res.render('register', { errorMessage });
            }

            // Hash the password before storing it in the database
            const hashedPassword = await bcrypt.hash(password, 10);

            // Create a new user instance
            const user = new User({
                username,
                password: hashedPassword,
                firstName,
                lastName,
                age,
                country,
                gender,
            });

            // Save the new user to the database
            await user.save();

            // Create nodemailer transporter for sending emails
            const transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: 'adiletzumabaj958@gmail.com',
                    pass: 'bkho kmqu ahgq gnil'
                }
            });

            // Compose email message
            const mailOptions = {
                from: 'adiletzumabaj958@gmail.com',
                to: user.username,
                subject: 'Welcome to our Portfolio Platform',
                text: `Thank you for registering with us! Your password is: ${password}`
            };

            // Send email to the user
            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.log(error);
                } else {
                    console.log('Email sent: ' + info.response);
                }
            });

            // Redirect to the login page with username parameter
            res.redirect(`/login?username=${encodeURIComponent(username)}`);
        } catch (error) {
            console.log(error);
            res.status(500).send('Internal Server Error'); // Handle server error
        }
    },

    // Method to render the login form
    getLogin: (req, res) => {
        res.render('login'); // Render the login view
    },

    // Method to handle user login
    postLogin: async (req, res) => {
        try {
            // Extract username and password from request body
            const { username, password } = req.body;

            // Find the user by username
            const user = await User.findOne({ username });

            if (!user) {
                const errorMessage = 'Invalid credentials';
                return res.render('login', { errorMessage });
            }

            // Compare hashed password with the provided password
            const isPasswordMatch = await bcrypt.compare(password, user.password);

            if (!isPasswordMatch) {
                // Increment login attempts and redirect for password reset if attempts exceed 3
                user.loginAttempts = (user.loginAttempts || 0) + 1;
                await user.save();

                if (user.loginAttempts === 3) {
                    return res.redirect(`/reset-password?username=${encodeURIComponent(username)}`);
                }

                const errorMessage = 'Invalid credentials';
                return res.render('login', { errorMessage });
            }

            // Reset login attempts for successful login
            user.loginAttempts = 0;
            await user.save();

            // Store user session and redirect to dashboard
            req.session.user = user;
            res.redirect('/dashboard');
        } catch (error) {
            console.log(error);
            res.status(500).send('Internal Server Error'); // Handle server error
        }
    },

    // Method to render the reset password form
    getResetPassword: (req, res) => {
        const { username } = req.query;
        res.render('reset-password', { username });
    },

    // Method to handle password reset
    postResetPassword: async (req, res) => {
        try {
            const { username, newPassword } = req.body;

            // Hash the new password
            const hashedPassword = await bcrypt.hash(newPassword, 10);

            // Update user's password in the database
            await User.updateOne({ username }, { password: hashedPassword });

            // Redirect to login page after password reset
            res.redirect('/login');
        } catch (error) {
            console.log(error);
            res.status(500).send('Internal Server Error'); // Handle server error
        }
    },

    // Method to render the user dashboard
    getDashboard: (req, res) => {
        if (!req.session.user) {
            return res.redirect('/login');
        }

        // Sample data for chart rendering
        const data = {
            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
            datasets: [{
                label: 'Sales',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1,
                data: [65, 59, 80, 81, 56, 55, 40]
            }]
        };

        const options = {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        };

        // Render the dashboard view with user data and chart options
        res.render('dashboard', {
            user: req.session.user,
            chart: {
                data: JSON.stringify(data),
                options: JSON.stringify(options)
            }
        });
    },

    // Method to handle user logout
    logout: (req, res) => {
        req.session.destroy((err) => {
            if (err) {
                console.log(err);
                res.status(500).send('Internal Server Error'); // Handle server error
            } else {
                res.redirect('/'); // Redirect to home page after logout
            }
        });
    }
};

module.exports = UserController; // Export the UserController object for use in other modules
